{% snapshot inventory_snapshot %}
{{
    config(
        target_schema='snapshots',
        unique_key='product_id',
        strategy='timestamp',
        updated_at='last_updated'
    )
}}

SELECT * FROM {{ ref('stg_inventory') }}

{% endsnapshot %}