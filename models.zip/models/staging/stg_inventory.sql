SELECT
    product_id,
    stock_level,
    last_updated
FROM {{ ref('inventory') }}