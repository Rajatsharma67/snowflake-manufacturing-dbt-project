{{ config(
    materialized='incremental',
    unique_key='production_id'
) }}

SELECT *
FROM {{ ref('stg_production') }}

{% if is_incremental() %}
WHERE updated_at > (SELECT MAX(updated_at) FROM {{ this }})
{% endif %}