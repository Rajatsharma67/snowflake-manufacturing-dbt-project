SELECT
    m.machine_id,
    m.machine_name,
    m.location,
    e.efficiency_pct
FROM {{ ref('stg_machines') }} m
LEFT JOIN {{ ref('int_machine_efficiency') }} e
ON m.machine_id = e.machine_id