{{ config(materialized='ephemeral') }}

SELECT
    p.machine_id,
    SUM(p.quantity) AS total_output,
    AVG(m.capacity) AS avg_capacity,
    (SUM(p.quantity) / AVG(m.capacity)) * 100 AS efficiency_pct
FROM {{ ref('stg_production') }} p
JOIN {{ ref('stg_machines') }} m
ON p.machine_id = m.machine_id
GROUP BY p.machine_id