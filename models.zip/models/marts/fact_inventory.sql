SELECT
    i.product_id,
    i.stock_level,
    s.stock_status
FROM {{ ref('stg_inventory') }} i
JOIN {{ ref('int_inventory_status') }} s
ON i.product_id = s.product_id