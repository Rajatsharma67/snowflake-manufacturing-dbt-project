{{ config(materialized='ephemeral') }}

SELECT
    product_id,
    stock_level,
    CASE 
        WHEN stock_level < 200 THEN 'LOW'
        WHEN stock_level BETWEEN 200 AND 800 THEN 'MEDIUM'
        ELSE 'HIGH'
    END AS stock_status
FROM {{ ref('stg_inventory') }}