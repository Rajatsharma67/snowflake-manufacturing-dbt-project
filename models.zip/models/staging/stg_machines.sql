SELECT
    machine_id,
    machine_name,
    location,
    capacity,
    updated_at
FROM {{ ref('machines') }}