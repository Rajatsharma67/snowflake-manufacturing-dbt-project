{{ config(materialized='view') }}

SELECT
    production_id,
    machine_id,
    product_id,
    production_date,
    quantity,
    updated_at
FROM {{ ref('production') }}